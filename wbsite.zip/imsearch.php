<?php require_once("res/x5engine.php"); ?><!DOCTYPE html><!-- HTML5 -->
<html lang="en-GB" dir="ltr">
	<head>
		<title>Search - MUTVBD</title>
		<meta charset="utf-8" />
		<!--[if IE]><meta http-equiv="ImageToolbar" content="False" /><![endif]-->
		<meta name="generator" content="Incomedia WebSite X5 Professional 11.0.5.24 - www.websitex5.com" />
		<meta name="viewport" content="width=960" />
		<link rel="icon" href="favicon.png" type="image/png" />
		<link rel="stylesheet" type="text/css" href="style/reset.css" media="screen,print" />
		<link rel="stylesheet" type="text/css" href="style/print.css" media="print" />
		<link rel="stylesheet" type="text/css" href="style/style.css" media="screen,print" />
		<link rel="stylesheet" type="text/css" href="style/template.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="style/menu.css" media="screen" />
		<!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="style/ie.css" media="screen" /><![endif]-->
		
		<script type="text/javascript" src="res/jquery.js?24"></script>
		<script type="text/javascript" src="res/x5engine.js?24"></script>
		<script type="text/javascript">
			x5engine.boot.push(function () { x5engine.bgStretch('style/bg.jpg', true, 0); });
		</script>
		
	</head>
	<body>
		<div id="imHeaderBg"></div>
		<div id="imFooterBg"></div>
		<div id="imPage">
			<div id="imHeader">
				<h1 class="imHidden">Search - MUTVBD</h1>
				
				<div style="position: absolute; top: 116px; left: 1px; width: 957px; height: 26px; overflow: hidden;"><marquee style="background-color:#FFFFFF; border-width:2px; border-style:solid; border-color:#000000; font-family:comic sans ms; font-size:14pt; text-color:#FF0000; "direction="left" behavior="scroll" scrollamount="9" onmouseover="this.stop()" onmouseout="this.start()" > <b> >>>> Like our page and get streaming links before matches start !! >>>> If any channel isn't working then please Contact with us and we'll fix it as soon as possible !! Bookmark Us !! Regards !! </b> <img src="http://2.bp.blogspot.com/-26Nliz37zhk/VQ7vMoagZ4I/AAAAAAAAArk/2D5qFCO1ahY/s1600/image%2B(10).gif" />   </marquee></div>
			</div>
			<a class="imHidden" href="#imGoToCont" title="Skip the main menu">Go to content</a>
			<a id="imGoToMenu"></a><p class="imHidden">Main menu:</p>
			<div id="imMnMn" class="auto">
				<ul class="auto">
					<li id="imMnMnNode0" class="imMnMnFirst">
						<a href="index.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>MUTVBD</span>
							</span>
						</a>
					</li><li id="imMnMnNode3" class="imMnMnMiddle">
						<a href="star-sports-1.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>Star Sports 1</span>
							</span>
						</a>
					</li><li id="imMnMnNode4" class="imMnMnMiddle">
						<a href="star-sports-2.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>Star Sports 2</span>
							</span>
						</a>
					</li><li id="imMnMnNode5" class="imMnMnMiddle">
						<a href="star-sports-3.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>Star Sports 3</span>
							</span>
						</a>
					</li><li id="imMnMnNode6" class="imMnMnMiddle">
						<a href="star-sports-4.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>star sports 4</span>
							</span>
						</a>
					</li><li id="imMnMnNode7" class="imMnMnMiddle">
						<a href="sky-sports-1.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sky sports 1</span>
							</span>
						</a>
					</li><li id="imMnMnNode8" class="imMnMnMiddle">
						<a href="sky-sports-2.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sky sports 2</span>
							</span>
						</a>
					</li><li id="imMnMnNode9" class="imMnMnMiddle">
						<a href="sky-sports-3.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sky sports 3</span>
							</span>
						</a>
					</li><li id="imMnMnNode10" class="imMnMnMiddle">
						<a href="sky-sports-4.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sky sports 4</span>
							</span>
						</a>
					</li><li id="imMnMnNode11" class="imMnMnMiddle">
						<a href="sky-sports-5.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sky sports 5</span>
							</span>
						</a>
					</li><li id="imMnMnNode12" class="imMnMnMiddle">
						<a href="sky-sports-news.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sky sports news</span>
							</span>
						</a>
					</li><li id="imMnMnNode13" class="imMnMnMiddle">
						<a href="ten-sports.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>ten sports</span>
							</span>
						</a>
					</li><li id="imMnMnNode14" class="imMnMnMiddle">
						<a href="ten-action.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>ten action</span>
							</span>
						</a>
					</li><li id="imMnMnNode15" class="imMnMnMiddle">
						<a href="ten-cricket.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>ten cricket</span>
							</span>
						</a>
					</li><li id="imMnMnNode16" class="imMnMnMiddle">
						<a href="bein-esp.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein esp</span>
							</span>
						</a>
					</li><li id="imMnMnNode17" class="imMnMnMiddle">
						<a href="bein-usa.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein usa</span>
							</span>
						</a>
					</li><li id="imMnMnNode18" class="imMnMnMiddle">
						<a href="ptv-sports.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>ptv sports</span>
							</span>
						</a>
					</li><li id="imMnMnNode19" class="imMnMnMiddle">
						<a href="eurosports.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>eurosports</span>
							</span>
						</a>
					</li><li id="imMnMnNode20" class="imMnMnMiddle">
						<a href="eurosports-2.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>eurosports 2</span>
							</span>
						</a>
					</li><li id="imMnMnNode21" class="imMnMnMiddle">
						<a href="wwe-network.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>wwe network</span>
							</span>
						</a>
					</li><li id="imMnMnNode22" class="imMnMnMiddle">
						<a href="tsn1.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>tsn1</span>
							</span>
						</a>
					</li><li id="imMnMnNode23" class="imMnMnMiddle">
						<a href="tsn2.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>tsn2</span>
							</span>
						</a>
					</li><li id="imMnMnNode24" class="imMnMnMiddle">
						<a href="premier-sports.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>premier sports</span>
							</span>
						</a>
					</li><li id="imMnMnNode25" class="imMnMnMiddle">
						<a href="sportsnet-one.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sportsnet one</span>
							</span>
						</a>
					</li><li id="imMnMnNode26" class="imMnMnMiddle">
						<a href="sportsnet-world.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sportsnet world</span>
							</span>
						</a>
					</li><li id="imMnMnNode27" class="imMnMnMiddle">
						<a href="sportsnet-ontario.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>sportsnet ontario</span>
							</span>
						</a>
					</li><li id="imMnMnNode28" class="imMnMnMiddle">
						<a href="dragon-ball-z.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>dragon ball z</span>
							</span>
						</a>
					</li><li id="imMnMnNode29" class="imMnMnMiddle">
						<a href="set-max.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>set max</span>
							</span>
						</a>
					</li><li id="imMnMnNode30" class="imMnMnMiddle">
						<a href="set-six.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>set six</span>
							</span>
						</a>
					</li><li id="imMnMnNode31" class="imMnMnMiddle">
						<a href="bein-sports-1.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 1</span>
							</span>
						</a>
					</li><li id="imMnMnNode32" class="imMnMnMiddle">
						<a href="bein-sports-2.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 2</span>
							</span>
						</a>
					</li><li id="imMnMnNode33" class="imMnMnMiddle">
						<a href="bein-sports-3.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 3</span>
							</span>
						</a>
					</li><li id="imMnMnNode34" class="imMnMnMiddle">
						<a href="bein-sports-4.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 4</span>
							</span>
						</a>
					</li><li id="imMnMnNode35" class="imMnMnMiddle">
						<a href="bein-sports-5.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 5</span>
							</span>
						</a>
					</li><li id="imMnMnNode36" class="imMnMnMiddle">
						<a href="-bein-sports-6.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span> bein sports 6</span>
							</span>
						</a>
					</li><li id="imMnMnNode37" class="imMnMnMiddle">
						<a href="bein-sports-7.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 7</span>
							</span>
						</a>
					</li><li id="imMnMnNode38" class="imMnMnMiddle">
						<a href="bein-sports-8.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 8</span>
							</span>
						</a>
					</li><li id="imMnMnNode39" class="imMnMnMiddle">
						<a href="bein-sports-9.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 9</span>
							</span>
						</a>
					</li><li id="imMnMnNode40" class="imMnMnMiddle">
						<a href="bein-sports-10.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 10</span>
							</span>
						</a>
					</li><li id="imMnMnNode41" class="imMnMnMiddle">
						<a href="bein-sports-11.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 11</span>
							</span>
						</a>
					</li><li id="imMnMnNode42" class="imMnMnMiddle">
						<a href="bein-sports-12.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 12</span>
							</span>
						</a>
					</li><li id="imMnMnNode43" class="imMnMnMiddle">
						<a href="bein-sports-13.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 13</span>
							</span>
						</a>
					</li><li id="imMnMnNode44" class="imMnMnMiddle">
						<a href="bein-sports-14.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>bein sports 14</span>
							</span>
						</a>
					</li><li id="imMnMnNode45" class="imMnMnMiddle">
						<a href="hd-stream-1.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>HD Stream 1</span>
							</span>
						</a>
					</li><li id="imMnMnNode46" class="imMnMnMiddle">
						<a href="hd-stream-2.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>HD Stream 2</span>
							</span>
						</a>
					</li><li id="imMnMnNode47" class="imMnMnMiddle">
						<a href="hd-stream-3.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>HD Stream 3</span>
							</span>
						</a>
					</li><li id="imMnMnNode48" class="imMnMnMiddle">
						<a href="hd-stream-4.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>HD Stream 4</span>
							</span>
						</a>
					</li><li id="imMnMnNode49" class="imMnMnLast">
						<a href="hd-stream-5.html">
							<span class="imMnMnFirstBg">
								<span class="imMnMnTxt"><span class="imMnMnImg"></span>HD Stream 5</span>
							</span>
						</a>
					</li>
				</ul>
			</div>
			<div id="imContentGraphics"></div>
			<div id="imContent">
				<a id="imGoToCont"></a>
				<h2 id="imPgTitle">Search results</h2><?php
$search = new imSearch();
$keys = isset($_GET['search']) ? $_GET['search'] : "";
$page = isset($_GET['page']) ? $_GET['page'] : 0;
$type = isset($_GET['type']) ? $_GET['type'] : "pages"; ?>
<div class="searchPageContainer">
<?php echo $search->search($keys, $page, $type); ?>
</div>
				  
				<div class="imClear"></div>
			</div>
			<div id="imFooter">
				
				<div style="position: absolute; top: 24px; left: 295px; width: 458px; height: 37px; overflow: hidden;"><b><u>© 2015 <a href="http://mutvbd.cf">www.mutvbd.cf </a> Designed by <a href="http://facebook.com/sifat.iv"> Sifat Ahmed IV </a></b></u></div>
			</div>
		</div>
		<span class="imHidden"><a href="#imGoToCont" title="Read this page again">Back to content</a> | <a href="#imGoToMenu" title="Read this site again">Back to main menu</a></span>
		
		<noscript class="imNoScript"><div class="alert alert-red">To use this website you must enable JavaScript</div></noscript>
	</body>
</html>
