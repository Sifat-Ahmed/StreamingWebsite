<?php

// Users data
$imSettings['access']['webregistrations_gid'] = 'd97v66o3';
$imSettings['access']['users'] = array(
	'admin' => array(
		'groups' => array('tcut8ryk'),
		'id' => 'tcut8ryk',
		'name' => 'Admin',
		'password' => 'do01awbo',
		'email' => '',
		'page' => 'index.html'
	),
	'newuser' => array(
		'groups' => array('4n7u7dg3'),
		'id' => '4n7u7dg3',
		'name' => 'NewUser',
		'password' => '079s2t9u',
		'email' => '',
		'page' => 'index.html'
	)
);

// Admins list
$imSettings['access']['admins'] = array('tcut8ryk');

// Page/Users permissions
$imSettings['access']['pages'] = array();

// End of file access.inc.php