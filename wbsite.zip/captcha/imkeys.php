<?php
	$oNameList = array("dhu","p3e","utj","msk","djj","thd","33w","gul","ht5","m7r");
	$oCharList = array("8","N","2","S","7","6","D","D","J","7");
// End of file imkeys.php